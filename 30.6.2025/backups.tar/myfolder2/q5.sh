#!/bin/bash
mkdir newfolder && cp /var/log/*.log newfolder/
